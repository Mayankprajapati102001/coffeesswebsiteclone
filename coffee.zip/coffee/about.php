
<?php include('header.php');?>

    <!-- about section  -->


    <section class="about_us  pb-5">
        <div class="container">
            <div class="heading">
                About <span>Us</span>

            </div>
            <div class="row">
                <div data-aos="fade-right" class="col-md-6">
                    <div class="img-div">
                        <img src="images/about.png" alt="" class="img-fluid ">
                    </div>
                </div>

                <div data-aos="fade-left" class="col-md-6">
                    <h3>What Makes Our Coffee Special?</h3>
                    <br>
                    <p>The word coffee entered the English language in 1582 via the Dutch koffie,
                        Though coffee is now a global commodity,it has a long history
                        <br>
                        <br>
                        Though coffee is now a global commodity,it has a long history
                        it has a long history tied closely
                        <br><br>
                        <br>to food traditions around the
                        <br> around the Red Sea.
                    </p>
                    <button id="about-btn">Learn More.</button>
                </div>

            </div>
        </div>
    </section>

  <?php include('footer.php');?>