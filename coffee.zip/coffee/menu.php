
<?php include('header.php');?>

       <!-- menu section -->

       <section class="menu pt-5">
        <div class="container">
            <div class="menu-div">
                <h2>Menu</h2>
            </div>
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m1.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$200
                                <strike class="strike-price">$300</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m2.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$250
                                <strike class="strike-price">$400</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m3.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$150
                                <strike class="strike-price">$310</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m4.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$160
                                <strike class="strike-price">$320</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m5.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$600
                                <strike class="strike-price">$900</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m6.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$260
                                <strike class="strike-price">$500</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m7.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$350
                                <strike class="strike-price">$700</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/m8.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <div class="star text-center">
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <h3>Coffee</h3>
                            <p class="price">$400
                                <strike class="strike-price">$800</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>


    <?php include('footer.php');?>
