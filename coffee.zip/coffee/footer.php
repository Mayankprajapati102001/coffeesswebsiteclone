<!-- footer section  -->


<footer class="footer-cafe ">
    <div class="footer-logo">
        <div class="footer-img">
            <a href="#">
                <img src="images/logo.png" alt="" width="200px">
            </a>
        </div>
        <div class="foot-icon py-3">


            <i class="fa fa-instagram"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-facebook"></i>
            <i class="fa fa-youtube"></i>
            <i class="fa fa-google"></i>

        </div>
        <div class="desing-bt">
            <h5>Design by
                <a href="#">Mayank</a>
            </h5>
        </div>
        <div class="copy-right">
            <p>@ &nbsp; Copyright
                <a href="">
                    Coffee Shop
                </a>
                . All Rights Reserved
            </p>
        </div>
    </div>

</footer>

<!-- aos cdn -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
</body>

</html>