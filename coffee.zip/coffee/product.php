<?php include('header.php');?>


    <!-- our  products  -->

    <section class="product">
        <div class="container">
            <div class="heading-product">
                <h3>
                    Products
                </h3>

            </div>
            <div class="product-div">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card">
                            <img src="images/arabica coffee.png" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h3>Arabica Coffee</h3>
                                <p class="price">$699
                                    <strike class="strike-price">$999</strike>
                                </p>
                                <p class="cart">
                                    <span>
                                        <i class="fa fa-shopping-cart"></i>
                                    </span>
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <img src="images/Black Coffee.png" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h3>Black Coffee</h3>
                                <p class="price">$1499
                                    <strike class="strike-price">$1999</strike>
                                </p>
                                <p class="cart">
                                    <span>
                                        <i class="fa fa-shopping-cart"></i>
                                    </span>
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <img src="images/Cappuccino coffee.png" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h3>Cappucino Coffee</h3>
                                <p class="price">$1699
                                    <strike class="strike-price">$1999</strike>
                                </p>
                                <p class="cart">
                                    <span>
                                        <i class="fa fa-shopping-cart"></i>
                                    </span>
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <img src="images/Decaf caffee.png" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h3>Decaf Coffee</h3>
                                <p class="price">$2599
                                    <strike class="strike-price">$2999</strike>
                                </p>
                                <p class="cart">
                                    <span>
                                        <i class="fa fa-shopping-cart"></i>
                                    </span>
                                </p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <?php include('footer.php');?>