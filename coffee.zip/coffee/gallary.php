
<?php include('header.php');?>

   <!-- our gallary -->

   <section class="Gallary">
    <div class="container">
        <div class="Our-gallary-heading">
            <h3>Our
                <span class="span-gallary">Gallary</span>
            </h3>
        </div>
        <div class="row g-3">
            <div data-aos="fade-right" class="col-md-4">
                <img src="images/image1.png" alt="" class="img-fluid">
            </div>
            <div data-aos="fade-up" class="col-md-4">
                <img src="images/image2.png" alt="" class="img-fluid">
            </div>
            <div data-aos="fade-left" class="col-md-4">
                <img src="images/image3.png" alt="" class="img-fluid">
            </div>

            <div data-aos="fade-right" class="col-md-4">
                <img src="images/image4.png" alt="" class="img-fluid">
            </div>

            <div data-aos="fade-down" class="col-md-4">
                <img src="images/image5.png" alt="" class="img-fluid">
            </div>

            <div data-aos="fade-left" class="col-md-4">
                <img src="images/image6.png" alt="" class="img-fluid">
            </div>

        </div>




    </div>
</section>

<?php include('footer.php');?>