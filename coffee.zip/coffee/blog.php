
<?php include('header.php');?>

  <!-- Latest blogs -->

  <section class="Latest-blog ">
    <div class="container">
        <div class="blog">
            <h2>Latest
                <span>Blogs</span>
            </h2>

        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="blog-img">
                    <img src="images/b1.png" alt="" class="img-fluid">


                    <h2>
                        Bandra Coffees Cafe
                    </h2>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic similique rem magni enim
                        voluptatem placeat!</p>

                    <button class="btn">Read More.</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="blog-img">
                    <img src="images/b2.png" alt="" class="img-fluid">


                    <h2>
                        Coffees With Work
                    </h2>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur esse non excepturi fuga
                        nobis accusamus?</p>

                    <button class="btn">Read More.</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="blog-img">
                    <img src="images/b3.png" alt="" class="img-fluid">


                    <h2>
                        Coffees Relax
                    </h2>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur numquam delectus porro
                        similique incidunt distinctio.</p>

                    <button class="btn">Read More.</button>
                </div>
            </div>

        </div>
    </div>

</section>


<?php include('footer.php');?>