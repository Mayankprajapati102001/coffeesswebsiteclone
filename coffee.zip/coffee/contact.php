
<?php include('header.php');?>


   <!-- contact us pending -->

   <section class="contact">
    <div class="container">
        <div class="div-contact">
            <div class="row">
                <div class="col-md-7">
                    <div class="text">
                        Contact
                        <span>Us</span>

                    </div>
                    <p>Coffee is a beverage brewed from roasted, ground coffee beans.
                        <br>
                        Please contact me for any quary realated Shop.
                        <br><br>
                        <input class="form-control" type="text" placeholder="Name"
                            aria-label="default input example">
                        <br>
                        <input class="form-control" type="text" placeholder="Email"
                            aria-label="default input example">

                        <br>
                        <input class="form-control" type="Number" placeholder="Nmber"
                            aria-label="default input example">

                        <br>
                        <button type="button" class="btn">Send Messages</button>
                </div>
                <div class="col-md-5" id="col">
                    <div class="info">
                        <h1>Info</h1>
                        <p> <i class="fa fa-envelope"></i> &nbsp;lucknowcoffes@gmail.com</p>
                        <p><i class="fa fa-phone"></i> +918887806760</p>
                        <p><i class="fa fa-map-marker"></i> Lucknow Coffes Cafe</p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae, culpa</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>


<?php include('footer.php');?>