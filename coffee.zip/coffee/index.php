<?php include('header.php'); ?>



<!-- home page  -->
<section class="Home">
    <div class="container-fluid">
        <div class="div-home">
            <h3>Start Your Day With a
                <br>
                Fress coffee
            </h3>
            <br>
            <p> Coffee is a beverage brewed from roasted, ground coffee beans.
                <br>
                It has the highest sales in the world market for hot drinks.
                <br>
                Darkly colored, bitter, and slightly acidic,
            </p>
            <a href="product.html">
                <button id="btn">Shop Now</button>
            </a>
        </div>

    </div>

</section>




<!-- About Us -->

<section class="about_us  pb-5">
        <div class="container">
            <div class="heading">
                About <span>Us</span>

            </div>
            <div class="row">
                <div data-aos="fade-right" class="col-md-6">
                    <div class="img-div">
                        <img src="images/about.png" alt="" class="img-fluid ">
                    </div>
                </div>

                <div data-aos="fade-left" class="col-md-6">
                    <h3>What Makes Our Coffee Special?</h3>
                    <br>
                    <p>The word coffee entered the English language in 1582 via the Dutch koffie,
                        Though coffee is now a global commodity,it has a long history
                        <br>
                        <br>
                        Though coffee is now a global commodity,it has a long history
                        it has a long history tied closely
                        <br><br>
                        <br>to food traditions around the
                        <br> around the Red Sea.
                    </p>
                    <button id="about-btn">Learn More.</button>
                </div>

            </div>
        </div>
    </section>

<!-- top categories  -->

<section class="categories-section pt-5">
    <div class="container">
        <div class="categories">
            Top <span>Categories</span>

        </div>
        <div class="row">
            <div class="col-md-4 pt-3">
                <div class="card" style="width: 21rem;">
                    <img src="images/c1.png" class="card-img-top" alt="...">
                </div>
            </div>
            <div class="col-md-4 pt-3">
                <div class="card" style="width: 21rem;">
                    <img src="images/c2.png" class="card-img-top" alt="...">
                </div>
            </div>
            <div class="col-md-4 pt-3 ">
                <div class="card" style="width: 21rem;">
                    <img src="images/c3.png" class="card-img-top" alt="...">
                </div>
            </div>
</section>

<!-- menu section -->

<section class="menu pt-5">
    <div class="container">
        <div class="menu-div">
            <h2>Menu</h2>
        </div>
        <div class="row g-3">
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m1.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$200
                            <strike class="strike-price">$300</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m2.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$250
                            <strike class="strike-price">$400</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m3.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$150
                            <strike class="strike-price">$310</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m4.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$160
                            <strike class="strike-price">$320</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m5.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$600
                            <strike class="strike-price">$900</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m6.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$260
                            <strike class="strike-price">$500</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m7.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$350
                            <strike class="strike-price">$700</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <img src="images/m8.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <div class="star text-center">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <h3>Coffee</h3>
                        <p class="price">$400
                            <strike class="strike-price">$800</strike>
                        </p>
                        <p class="cart">
                            <span>
                                <i class="fa fa-shopping-cart"></i>
                            </span>
                        </p>

                    </div>
                </div>
            </div>

        </div>
    </div>

</section>

<!-- our  products  -->

<section class="product">
    <div class="container">
        <div class="heading-product">
            <h3>
                Products
            </h3>

        </div>
        <div class="product-div">
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/arabica coffee.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Arabica Coffee</h3>
                            <p class="price">$699
                                <strike class="strike-price">$999</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/Black Coffee.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Black Coffee</h3>
                            <p class="price">$1499
                                <strike class="strike-price">$1999</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/Cappuccino coffee.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Cappucino Coffee</h3>
                            <p class="price">$1699
                                <strike class="strike-price">$1999</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="images/Decaf caffee.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h3>Decaf Coffee</h3>
                            <p class="price">$2599
                                <strike class="strike-price">$2999</strike>
                            </p>
                            <p class="cart">
                                <span>
                                    <i class="fa fa-shopping-cart"></i>
                                </span>
                            </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

<!-- our gallary -->


<section class="Gallary">
    <div class="container">
        <div class="Our-gallary-heading">
            <h3>Our
                <span class="span-gallary">Gallary</span>
            </h3>
        </div>
        <div class="row g-3">
            <div data-aos="fade-right" class="col-md-4">
                <img src="images/image1.png" alt="" class="img-fluid">
            </div>
            <div data-aos="fade-up" class="col-md-4">
                <img src="images/image2.png" alt="" class="img-fluid">
            </div>
            <div data-aos="fade-left" class="col-md-4">
                <img src="images/image3.png" alt="" class="img-fluid">
            </div>

            <div data-aos="fade-right" class="col-md-4">
                <img src="images/image4.png" alt="" class="img-fluid">
            </div>

            <div data-aos="fade-down" class="col-md-4">
                <img src="images/image5.png" alt="" class="img-fluid">
            </div>

            <div data-aos="fade-left" class="col-md-4">
                <img src="images/image6.png" alt="" class="img-fluid">
            </div>

        </div>




    </div>
</section>


<!-- contact us pending -->

<section class="contact">
    <div class="container">
        <div class="div-contact">
            <div class="row">
                <div class="col-md-7">
                    <div class="text">
                        Contact
                        <span>Us</span>

                    </div>
                    <p>Coffee is a beverage brewed from roasted, ground coffee beans.
                        <br>
                        Please contact me for any quary realated Shop.
                        <br><br>
                        <input class="form-control" type="text" placeholder="Name" aria-label="default input example">
                        <br>
                        <input class="form-control" type="text" placeholder="Email" aria-label="default input example">

                        <br>
                        <input class="form-control" type="Number" placeholder="Nmber"
                            aria-label="default input example">

                        <br>
                        <button type="button" class="btn">Send Messages</button>
                </div>
                <div class="col-md-5" id="col">
                    <div class="info">
                        <h1>Info</h1>
                        <p> <i class="fa fa-envelope"></i> &nbsp;lucknowcoffes@gmail.com</p>
                        <p><i class="fa fa-phone"></i> +918887806760</p>
                        <p><i class="fa fa-map-marker"></i> Lucknow Coffes Cafe</p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae, culpa</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>


<!-- Latest blogs -->

<section class="Latest-blog ">
    <div class="container">
        <div class="blog">
            <h2>Latest
                <span>Blogs</span>
            </h2>

        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="blog-img">
                    <img src="images/b1.png" alt="" class="img-fluid">


                    <h2>
                        Bandra Coffees Cafe
                    </h2>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic similique rem magni enim
                        voluptatem placeat!</p>

                    <button class="btn">Read More.</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="blog-img">
                    <img src="images/b2.png" alt="" class="img-fluid">


                    <h2>
                        Coffees With Work
                    </h2>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur esse non excepturi fuga
                        nobis accusamus?</p>

                    <button class="btn">Read More.</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="blog-img">
                    <img src="images/b3.png" alt="" class="img-fluid">


                    <h2>
                        Coffees Relax
                    </h2>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur numquam delectus porro
                        similique incidunt distinctio.</p>

                    <button class="btn">Read More.</button>
                </div>
            </div>

        </div>
    </div>

</section>


<?php include('footer.php'); ?>